# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

datasetx = pd.read_csv('batting.csv',engine='python',usecols = ['Player','Opposition','Ground',
                                                                'Innings_Runs_Scored_Num',
                                                                'Innings_Not_Out_Flag',
                                                                'Innings Balls Faced','100','50'])
datasetx['Innings_Not_Out_Flag'] = datasetx['Innings_Not_Out_Flag'].replace(to_replace =0,value =2 )
datasetx['Innings_Not_Out_Flag'] = datasetx['Innings_Not_Out_Flag'].replace(to_replace =1,value =0 )
datasetx['Innings_Out_Flag'] = datasetx['Innings_Not_Out_Flag'].replace(to_replace =2,value =1 )
datasetx['Innings_Not_Out_Flag'] = pd.read_csv('batting.csv',engine='python',usecols = ['Innings_Not_Out_Flag'])


A = pd.DataFrame()
A = datasetx.groupby(['Player','Opposition'],as_index =False)[['Innings_Runs_Scored_Num',
                    'Innings Balls Faced','100','50','Innings_Not_Out_Flag','Innings_Out_Flag']].sum()
B = pd.DataFrame()
B = datasetx.groupby(['Player','Ground'],as_index =False)[['Innings_Runs_Scored_Num',
                    'Innings Balls Faced','100','50','Innings_Not_Out_Flag','Innings_Out_Flag']].sum()

A['Innings_Runs_Scored_Num'] = A['Innings_Runs_Scored_Num']/3
A['Innings Balls Faced'] = A['Innings Balls Faced']/3
A['100'] = A['100']/3
A['50'] = A['50']/3
A['Innings_Not_Out_Flag'] = A['Innings_Not_Out_Flag']/3 
A['Innings_Out_Flag'] = A['Innings_Out_Flag']/3

B['Innings_Runs_Scored_Num'] = B['Innings_Runs_Scored_Num']/3
B['Innings Balls Faced'] = B['Innings Balls Faced']/3
B['100'] = B['100']/3
B['50'] = B['50']/3
B['Innings_Not_Out_Flag'] = B['Innings_Not_Out_Flag']/3 
B['Innings_Out_Flag'] = B['Innings_Out_Flag']/3

X =A.iloc[:,:].values

avg_opposition =[]
no_of_innings = []
strike_rate__opposition = []
for i in range(0,len(X[:,0])) :
    if X[i,7] == 0:
        avg_opposition.append(X[i,2])
    else :
        avg_opposition.append(X[i,2]/X[i,7])
    if X[i,3] == 0:
        strike_rate__opposition.append(X[i,2]*100)
    else :
        strike_rate__opposition.append(X[i,2]*100/X[i,3])      
    no_of_innings.append(X[i,6]+X[i,7])
    
A['avg_opposition']=avg_opposition
A['strike_rate__opposition']=strike_rate__opposition
A['no_of_innings']=no_of_innings



X =B.iloc[:,:].values

avg_Ground =[]
no_of_inningsGround = []
strike_rate_Ground = []
for i in range(0,len(X[:,0])) :
    if X[i,7] == 0:
        avg_Ground.append(X[i,2])
    else :
        avg_Ground.append(X[i,2]/X[i,7])
    if X[i,3] == 0:
        strike_rate_Ground.append(X[i,2]*100)
    else :
        strike_rate_Ground.append(X[i,2]*100/X[i,3])      
    no_of_inningsGround.append(X[i,6]+X[i,7])
    
B['avg_Ground']=avg_Ground
B['strike_rate_Ground']=strike_rate_Ground
B['no_of_inningsGround']=no_of_inningsGround


X =A.iloc[:,:].values
opposition_score =[]
for i in range(0,len(X[:,0])) :
    opposition_score.append(0.4262*X[i,8]+0.2566*X[i,10]+0.1501*X[i,9]+0.0787*X[i,4]+0.0556*X[i,5])

X =B.iloc[:,:].values
venue_score =[]
for i in range(0,len(X[:,0])) :
    venue_score.append(0.4262*X[i,8]+0.2566*X[i,10]+0.1501*X[i,9]+0.0787*X[i,4]+0.0556*X[i,5])
    
    
A['opposition_score']=opposition_score
B['venue_score']=venue_score

c = pd.DataFrame()
c['Player']=A['Player']
c['Opposition']=A['Opposition']
c['avg_opposition']=A['avg_opposition']
c['strike_rate__opposition']=A['strike_rate__opposition']
c['no_of_innings_opposition']=A['no_of_innings']
c['opposition_score']=A['opposition_score']
datasetx = pd.read_csv('Innings_wise_Batting.csv')
newdf = pd.DataFrame()
newdf = pd.merge(datasetx,c,on=['Player','Opposition'])

c = pd.DataFrame()
c['Player']=B['Player']
c['Ground']=B['Ground']
c['avg_Ground']=B['avg_Ground']
c['strike_rate_Ground']=B['strike_rate_Ground']
c['no_of_inningsGround']=B['no_of_inningsGround']
c['venue_score']=B['venue_score']
datasetx = pd.read_csv('Innings_wise_Batting.csv')
#newdf = pd.DataFrame()
newdf = pd.merge(newdf,c,on=['Player','Ground'])

newdf.to_csv('finalbatting.csv',index = False)
