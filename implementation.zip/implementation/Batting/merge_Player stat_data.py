# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
dataset = pd.read_csv('Men ODI 21st Century.csv')
dataset = dataset[dataset.Country == 'India']


dataFrame_opt = pd.DataFrame()
dataFrame_opt['Player'] = dataset['Innings Player'] 
dataFrame_opt['Innings_Runs_Scored_Num'] = dataset['Innings Runs Scored Num']
dataFrame_opt['Innings_Not_Out_Flag'] = dataset['Innings Not Out Flag']
dataFrame_opt['100']=dataset["100's"]
dataFrame_opt['50']=dataset["50's"]
dataFrame_opt['Innings Balls Faced'] =dataset['Innings Balls Faced']
dataFrame_opt['Innings_Number'] = dataset['Innings Number']
dataFrame_opt['Opposition'] = dataset['Opposition']
dataFrame_opt['Ground'] = dataset['Ground']
dataFrame_opt['Innings Runs Scored Buckets'] = dataset['Innings Runs Scored Buckets']
#dataFrame_opt[''] = dataset['']

dataFrame_opt = dataFrame_opt[dataFrame_opt.Innings_Runs_Scored_Num != '-']
dataFrame_opt = dataFrame_opt[dataFrame_opt.Innings_Number != '-']
dataFrame_opt['Innings_Runs_Scored_Num'] = pd.to_numeric(dataFrame_opt['Innings_Runs_Scored_Num'])
dataFrame_opt['Innings Balls Faced'] =pd.to_numeric(dataFrame_opt['Innings Balls Faced'])
dataFrame_opt['Innings_Number'] = pd.to_numeric(dataFrame_opt['Innings_Number'])


data2 = pd.read_csv('players.csv')
newdf = pd.DataFrame()
newdf = pd.merge(dataFrame_opt,data2,on='Player')
newdf = newdf.dropna()
newdf.to_csv('batting.csv',index = False)