# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

import matplotlib.pyplot as plt


datasety = pd.read_csv('batting.csv',engine='python',usecols = ['Innings_Runs_Scored_Num'])
print(datasety.std()[0])
#result = datasety.sort_values(['Innings_Runs_Scored_Num'], ascending=[1])
result2 = datasety.groupby(['Innings_Runs_Scored_Num'])['Innings_Runs_Scored_Num'].count()
plt.title('visualaizing score')
plt.xlabel('runs scored by players')
plt.ylabel('count(no of runs)')
plt.scatter(result2.index,result2,s = 3 ,marker = 'o')
plt.show()
X = datasety.iloc[:,:].values
bucket= []
bucketclass = []
print(X[:,0])
for i in range(0,len(X[:,0])) :
    if X[i,0] < 25 :
        bucket.append("0-24")
        bucketclass.append(1)
    elif X[i,0] >= 25 and X[i,0] < 50 :
        bucket.append("25-49")
        bucketclass.append(2)
    elif X[i,0] >= 50 and X[i,0] < 75 :
        bucket.append("50-74")
        bucketclass.append(3)
    elif X[i,0] >= 75 and X[i,0] < 100 :
        bucket.append("75-99")
        bucketclass.append(4)
    else :
        bucket.append("100+")
        bucketclass.append(5)
datasetx = pd.read_csv('batting.csv',engine='python',usecols = ['Player','Innings_Number',
                                                                'Opposition','Ground','Total_Runs_Scored',
                                                                'Total_Out','Total_Not_Out','100s','50s','Balls Faced',
                                                                'Batting_Average','Strike Rate','consistancy'])
datasetx['score_bucket'] = bucket
datasetx['score_class'] = bucketclass
datasetx.to_csv('Innings_wise_Batting.csv',index = False)