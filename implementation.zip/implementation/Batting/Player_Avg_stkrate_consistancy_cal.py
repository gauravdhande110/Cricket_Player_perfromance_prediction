# -*- coding: utf-8 -*-
# importing Dataset
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
dataset = pd.read_csv('Men ODI 21st Century.csv')
# Considering inidan player innings.
dataset = dataset[dataset.Country == 'India']
dataFrame_operational = pd.DataFrame()
dataFrame_operational['Innings Player'] = dataset['Innings Player'] 
dataFrame_operational['Innings_Runs_Scored_Num'] = dataset['Innings Runs Scored Num']
dataFrame_operational['Innings_Not_Out_Flag'] = dataset['Innings Not Out Flag']
dataFrame_operational['100s']=dataset["100's"]
dataFrame_operational['50s']=dataset["50's"]
dataFrame_operational['Innings Balls Faced'] =dataset['Innings Balls Faced']
dataFrame_operational['Innings_Not_Out_Flag'] = dataFrame_operational['Innings_Not_Out_Flag'].replace(to_replace =0,value =2 )
dataFrame_operational['Innings_Not_Out_Flag'] = dataFrame_operational['Innings_Not_Out_Flag'].replace(to_replace =1,value =0 )
dataFrame_operational['Innings_Out_Flag'] = dataFrame_operational['Innings_Not_Out_Flag'].replace(to_replace =2,value =1 )
dataFrame_operational['Innings_Not_Out_Flag'] = dataset['Innings Not Out Flag']
dataFrame_operational = dataFrame_operational[dataFrame_operational.Innings_Runs_Scored_Num != '-']
#dataFrame_operational = dataFrame_operational[dataFrame_operational.Innings_Runs_Scored_Num != 'NAN']
dataFrame_operational['Innings_Runs_Scored_Num'] = pd.to_numeric(dataFrame_operational['Innings_Runs_Scored_Num'])
dataFrame_operational['Innings Balls Faced'] =pd.to_numeric(dataFrame_operational['Innings Balls Faced'])

#dataFrame_operational = dataFrame_operational[dataFrame_operational.Innings_Runs_Scored_Num != 0]




A = pd.DataFrame()
b= pd.DataFrame()
A = dataFrame_operational.groupby('Innings Player',as_index =False)[['Innings_Runs_Scored_Num','Innings_Out_Flag','Innings_Not_Out_Flag','100s','50s','Innings Balls Faced',]].sum()
b['Player']= A['Innings Player']
b['Total_Runs_Scored']=A['Innings_Runs_Scored_Num']/3
b['Total_Out'] = A['Innings_Out_Flag']/3 
b['Total_Not_Out'] = A['Innings_Not_Out_Flag']/3
b['100s']=A['100s']/3
b['50s']=A['50s']/3
b['Balls Faced']=A['Innings Balls Faced']/3
X = b.iloc[:,:].values

Batting_Average = []
Strike_Rate = []
consistancy = []
for i in range(0, len(X[:,1])):
    if X[i][2] ==0 :
        Batting_Average.append(X[i][1])
    else:
        Batting_Average.append(X[i][1]/X[i][2])
        
    if X[i][6] ==0 :
        
        Strike_Rate.append(X[i][1]*100)
    else:
        
        Strike_Rate.append((X[i][1]/X[i][6])*100)
    
b['Batting_Average'] = Batting_Average        
b['Strike Rate']  = Strike_Rate
X = b.iloc[:,:].values
for i in range(0, len(X[:,1])):
    consistancy.append(0.4262*X[i,7]+0.2566*X[i,8]+0.1510*(X[i,2]+X[i,3])+0.0787*X[i,4]+0.0556*X[i,5])
b['consistancy']=consistancy
b.to_csv('players.csv',index = False)


