# -*- coding: utf-8 -*-

import runpy
runpy.run_module(mod_name='create_players_list')
runpy.run_module(mod_name='merge_player stat_data')
runpy.run_module(mod_name='wicket_bucket')
runpy.run_module(mod_name='opponet_venue_score')
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


from sklearn import metrics
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
import matplotlib.pyplot as plt



datasety = pd.read_csv('finalbowling.csv',engine='python',usecols = ['Wicket_class'])
datasetx = pd.read_csv('finalbowling.csv',engine='python',usecols = ['Player','Opposition',
                                                                     'Ground','Total_Overs_Bowled'
                                                                     ,'Total_Wickets_Taken',
                                                                     'Total_Innings_Bowled',
                                                                     'Total_5_Wickets','Total_Maidens_Bowled'
                                                                     ,'Total_Runs_Conceded','Bowling_Average',
                                                                     'Bowling_Strike Rate','consistancy',
                                                                     'avg_opposition','stk_opposition',
                                                                     'opposition_score','avg_Ground',
                                                                     'stk_Ground','venue_score'])


from sklearn.preprocessing import LabelEncoder   
le = LabelEncoder() 

datasetx['Player']= le.fit_transform(datasetx['Player']) 
datasetx['Opposition']= le.fit_transform(datasetx['Opposition'])
datasetx['Ground']= le.fit_transform(datasetx['Ground'])



from sklearn.model_selection import train_test_split
X_train , X_test ,y_train,y_test = train_test_split(datasetx,datasety,test_size = 0.2 , random_state =23)


from sklearn.neighbors import KNeighborsClassifier
model = KNeighborsClassifier(n_neighbors=2)
model.fit(X_train,y_train)
predictedknn= model.predict(X_test) 
from sklearn.metrics import confusion_matrix
conknn = confusion_matrix(y_test,predictedknn)
print("Accuracyknn:",metrics.accuracy_score(y_test,predictedknn)*100)




from sklearn.tree import DecisionTreeClassifier
declf = DecisionTreeClassifier()
declf = declf.fit(X_train,y_train)
predictedDT= declf.predict(X_test)
conDT = confusion_matrix(y_test,predictedDT)
print("AccuracyDT:",metrics.accuracy_score(y_test,predictedDT)*100)


from sklearn.naive_bayes import GaussianNB
modelNB = GaussianNB()
modelNB.fit(X_train,y_train)
predictedNB= modelNB.predict(X_test)
conNB = confusion_matrix(y_test,predictedNB)
#print("AccuracyNB:",metrics.accuracy_score(y_test,predictedNB)*100)





from sklearn.svm import SVC
clf = SVC(gamma='auto')
clf.fit(X_train, y_train) 
#SVC(C=1.0, cache_size=200, class_weight=None, coef0=0.0,
    #decision_function_shape='ovr', degree=3, gamma='auto', kernel='rbf',
    #max_iter=-1, probability=False, random_state=None, shrinking=True,
    #stol=0.001, verbose=False)
predictedSVC = clf.predict(X_test) 


from sklearn.ensemble import RandomForestClassifier
forestclass=RandomForestClassifier(n_estimators=100)
forestclass.fit(X_train,y_train)
predictedRF=forestclass.predict(X_test)
#predictedRF=forestclass.predict(X_test)
conRF = confusion_matrix(y_test,predictedRF)




label=['K-nn acc','K-nn pre', 'DTree acc','DTree pre',
       'SVM acc','SVM pre','RanFor acc','RanFor pre' ]

acc= [
    metrics.accuracy_score(y_test,predictedknn)*100,
    precision_score(y_test,predictedknn,average='weighted')*100,
    #recall_score(y_test,predictedknn,average='weighted')*100,
    metrics.accuracy_score(y_test,predictedDT)*100,
    precision_score(y_test,predictedDT,average='weighted')*100,
    #recall_score(y_test,predictedDT,average='weighted')*100,
    #metrics.accuracy_score(y_test,predictedNB)*100,
    #precision_score(y_test,predictedNB,average='weighted')*100,
    #recall_score(y_test,predictedNB,average='weighted')*100,
    metrics.accuracy_score(y_test,predictedSVC)*100,
    precision_score(y_test,predictedSVC,average='weighted')*100,
    #recall_score(y_test,predictedSVC,average='weighted')*100,
    metrics.accuracy_score(y_test,predictedRF)*100,
    precision_score(y_test,predictedRF,average='weighted')*100,
    #recall_score(y_test,predictedRF,average='weighted')*100

]
#plt.figure(figsize=(15,15))

print(acc)
index = np.arange(len(label))
plt.bar(index,acc, color=['cyan','peachpuff'])
plt.xlabel('Accuracy , Precision', fontsize=10)
plt.ylabel('In Percentage', fontsize=10)
plt.xticks(index, label, fontsize=10, rotation=30)
plt.title('Classification Algorithm')
plt.ylim(0,100)
plt.savefig('report_acc_pre.png')
plt.show()

