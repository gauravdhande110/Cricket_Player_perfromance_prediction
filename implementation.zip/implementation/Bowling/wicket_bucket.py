# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


datasety = pd.read_csv('bowling.csv',engine='python',usecols = ['Innings Wickets Taken'])



X = datasety.iloc[:,:].values
bucket= []
bucketclass = []
print(X[:,0])
for i in range(0,len(X[:,0])) :
    if X[i,0] < 2 :
        bucket.append("0 or 1")
        bucketclass.append(1)
    elif X[i,0] >= 2 and X[i,0] < 4 :
        bucket.append("2 or 3")
        bucketclass.append(2)
    else :
        bucket.append("4+")
        bucketclass.append(3)
datasetx = pd.read_csv('bowling.csv')

datasetx['Wicket_bucket'] = bucket
datasetx['Wicket_class'] = bucketclass
datasetx.to_csv('Innings_wise_Bowling.csv',index = False)