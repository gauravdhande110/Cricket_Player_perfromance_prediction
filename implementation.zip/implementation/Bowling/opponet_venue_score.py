# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

data = pd.read_csv('Innings_wise_bowling.csv')


A = pd.DataFrame()
A = data.groupby(['Player','Opposition'],as_index =False)[['Innings_Overs_Bowled',
                    'Innings_Bowled_Flag','Innings Wickets Taken','Innings Runs Conceded','5 Wickets']].sum()


B = pd.DataFrame()
B = data.groupby(['Player','Ground'],as_index =False)[['Innings_Overs_Bowled',
                    'Innings_Bowled_Flag','Innings Wickets Taken','Innings Runs Conceded','5 Wickets']].sum()

C= pd.DataFrame()
C['Player']=A['Player']
C['Opposition']=A['Opposition']
C['Opposition_Overs_Bowled'] = A['Innings_Overs_Bowled']/3
C['Opposition_Bowled_count'] = A['Innings_Bowled_Flag']/3
C['Opposition_Wickets_Taken'] = A['Innings Wickets Taken']/3
C['Opposition_Runs Conceded'] = A['Innings Runs Conceded']/3
C['Opposition_5 Wickets'] = A['5 Wickets']/3 

avg_opposition = []
stk_opposition = []

X = C.iloc[:,:].values

for i in range(0,len(X[:,1])) :
    if X[i,4] == 0:
        avg_opposition.append(X[i,5])
        stk_opposition.append(X[i,2]*6)
    else :
        avg_opposition.append(X[i,5]/X[i,4])
        stk_opposition.append(X[i,2]*6/X[i,4])      
    
C['avg_opposition']=avg_opposition
C['stk_opposition']=stk_opposition



X = C.iloc[:,:].values
opposition_score =[]
for i in range(0,len(X[:,0])) :
    opposition_score.append(0.3177*X[i,2]+0.3177*X[i,3]+0.1933*X[i,8]+0.1465*X[i,7]+0.0943*X[i,6])
C['opposition_score']=opposition_score



datasetx = pd.read_csv('Innings_wise_bowling.csv')
newdf = pd.DataFrame()
newdf = pd.merge(datasetx,C,on=['Player','Opposition'])


C= pd.DataFrame()
C['Player']=B['Player']
C['Ground']=B['Ground']
C['Ground_Overs_Bowled'] = B['Innings_Overs_Bowled']/3
C['Ground_Bowled_count'] = B['Innings_Bowled_Flag']/3
C['Ground_Wickets_Taken'] = B['Innings Wickets Taken']/3
C['Ground_Runs Conceded'] = B['Innings Runs Conceded']/3
C['Ground_5 Wickets'] = B['5 Wickets']/3 

avg_Ground = []
stk_Ground = []

X = C.iloc[:,:].values

for i in range(0,len(X[:,1])) :
    if X[i,4] == 0:
        avg_Ground.append(X[i,5])
        stk_Ground.append(X[i,2]*6)
    else :
        avg_Ground.append(X[i,5]/X[i,4])
        stk_Ground.append(X[i,2]*6/X[i,4])      
    
C['avg_Ground']=avg_Ground
C['stk_Ground']=stk_Ground



X = C.iloc[:,:].values
Ground_score =[]
for i in range(0,len(X[:,0])) :
    Ground_score.append(0.3177*X[i,2]+0.3177*X[i,3]+0.1933*X[i,8]+0.1465*X[i,7]+0.0943*X[i,6])
C['venue_score']=Ground_score

newdf = pd.merge(newdf,C,on=['Player','Ground'])


newdf.to_csv('finalbowling.csv',index = False)


