# -*- coding: utf-8 -*-


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
dataset = pd.read_csv('Men ODI 21st Century.csv')
dataset = dataset[dataset.Country == 'India']

dataFrame_operational = pd.DataFrame()
dataFrame_operational['Player'] = dataset['Innings Player'] 
dataFrame_operational['Innings_Overs_Bowled'] = dataset['Innings Overs Bowled'] 
dataFrame_operational['Innings_Bowled_Flag'] = dataset['Innings Bowled Flag'] 
dataFrame_operational['Innings Maidens Bowled'] = dataset['Innings Maidens Bowled'] 
dataFrame_operational['Innings Runs Conceded'] = dataset['Innings Runs Conceded'] 
dataFrame_operational['Innings Wickets Taken'] = dataset['Innings Wickets Taken'] 
#dataFrame_operational['4 Wickets'] = dataset['4 Wickets'] 
dataFrame_operational['5 Wickets'] = dataset['5 Wickets'] 
dataFrame_operational['Opposition'] = dataset['Opposition'] 
dataFrame_operational['Ground'] = dataset['Ground'] 

#dataFrame_operational['10 Wickets'] = dataset['10 Wickets'] 
#dataFrame_operational['Innings Economy Rate'] = dataset['Innings Economy Rate'] 
#dataFrame_operational['Innings Wickets Taken Buckets'] = dataset['Innings Wickets Taken Buckets'] 
dataFrame_operational = dataFrame_operational[dataFrame_operational.Innings_Bowled_Flag != 0]
dataFrame_operational = dataFrame_operational.dropna()
dataFrame_operational['Innings_Overs_Bowled'] = pd.to_numeric(dataFrame_operational['Innings_Overs_Bowled'])
dataFrame_operational['Innings Maidens Bowled'] = pd.to_numeric(dataFrame_operational['Innings Maidens Bowled'])
dataFrame_operational['Innings Runs Conceded'] = pd.to_numeric(dataFrame_operational['Innings Runs Conceded'])
#dataFrame_operational['Innings Economy Rate'] = pd.to_numeric(dataFrame_operational['Innings Economy Rate'])
dataFrame_operational['Innings Wickets Taken'] = pd.to_numeric(dataFrame_operational['Innings Wickets Taken'])




data2 = pd.read_csv('players.csv')
newdf = pd.DataFrame()
newdf = pd.merge(dataFrame_operational,data2,on='Player')
newdf = newdf.dropna()
newdf.to_csv('bowling.csv',index = False)
