# -*- coding: utf-8 -*-

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
dataset = pd.read_csv('Men ODI 21st Century.csv')
dataset = dataset[dataset.Country == 'India']

dataFrame_operational = pd.DataFrame()
dataFrame_operational['Innings Player'] = dataset['Innings Player'] 
dataFrame_operational['Innings_Overs_Bowled'] = dataset['Innings Overs Bowled'] 
dataFrame_operational['Innings_Bowled_Flag'] = dataset['Innings Bowled Flag'] 
dataFrame_operational['Innings Maidens Bowled'] = dataset['Innings Maidens Bowled'] 
dataFrame_operational['Innings Runs Conceded'] = dataset['Innings Runs Conceded'] 
dataFrame_operational['Innings Wickets Taken'] = dataset['Innings Wickets Taken'] 
#dataFrame_operational['4 Wickets'] = dataset['4 Wickets'] 
dataFrame_operational['5 Wickets'] = dataset['5 Wickets'] 
#dataFrame_operational['10 Wickets'] = dataset['10 Wickets'] 
#dataFrame_operational['Innings Economy Rate'] = dataset['Innings Economy Rate'] 
#dataFrame_operational['Innings Wickets Taken Buckets'] = dataset['Innings Wickets Taken Buckets'] 
dataFrame_operational = dataFrame_operational[dataFrame_operational.Innings_Bowled_Flag != 0]
dataFrame_operational = dataFrame_operational.dropna()
dataFrame_operational['Innings_Overs_Bowled'] = pd.to_numeric(dataFrame_operational['Innings_Overs_Bowled'])
dataFrame_operational['Innings Maidens Bowled'] = pd.to_numeric(dataFrame_operational['Innings Maidens Bowled'])
dataFrame_operational['Innings Runs Conceded'] = pd.to_numeric(dataFrame_operational['Innings Runs Conceded'])
#dataFrame_operational['Innings Economy Rate'] = pd.to_numeric(dataFrame_operational['Innings Economy Rate'])
dataFrame_operational['Innings Wickets Taken'] = pd.to_numeric(dataFrame_operational['Innings Wickets Taken'])





A = pd.DataFrame()
A = dataFrame_operational.groupby('Innings Player',as_index =False)[['Innings_Overs_Bowled',
                                 'Innings_Bowled_Flag','Innings Maidens Bowled'
                                 ,'Innings Runs Conceded','5 Wickets','Innings Wickets Taken'
                                 ]].sum()
b= pd.DataFrame()
b['Player']= A['Innings Player']
b['Total_Overs_Bowled']=A['Innings_Overs_Bowled']/3
b['Total_Wickets_Taken'] = A['Innings Wickets Taken']/3 
b['Total_Innings_Bowled'] = A['Innings_Bowled_Flag']/3
#b['Total_4_Wickets']=A['4 Wickets']/3
b['Total_5_Wickets']=A['5 Wickets']/3
b['Total_Maidens_Bowled']=A['Innings Maidens Bowled']/3
b['Total_Runs_Conceded']=A['Innings Runs Conceded']/3

X = b.iloc[:,:].values




Bowling_Average = []
Bowling_Strike_Rate = []
consistancy = []
for i in range(0, len(X[:,1])):
    if X[i][2] ==0 :
        Bowling_Average.append(X[i][6])
        Bowling_Strike_Rate.append(X[i][1]*6)   
    else:
        Bowling_Average.append(X[i][6]/X[i][2])
        Bowling_Strike_Rate.append((X[i][1]/X[i][2])*6)
        
b['Bowling_Average'] = Bowling_Average        
b['Bowling_Strike Rate']  = Bowling_Strike_Rate
X = b.iloc[:,:].values
for i in range(0, len(X[:,1])):
    consistancy.append(0.4174*X[i,1]+0.2634*X[i,3]+0.1602*X[i,8]+0.0975*X[i,7]+0.0615*X[i,4])
b['consistancy']=consistancy
b.to_csv('players.csv',index = False)


